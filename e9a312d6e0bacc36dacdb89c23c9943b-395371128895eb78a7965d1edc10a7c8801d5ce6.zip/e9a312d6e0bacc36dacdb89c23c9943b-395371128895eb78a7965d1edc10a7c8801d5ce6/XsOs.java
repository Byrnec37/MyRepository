package Week3;

import java.util.Scanner;

/**
 * Created by Conor Byrne on 17/04/2019
 * Description: Play a game of Xs and Os.
 */

public class XsOs {
    public static void main(String[] args) {
        Scanner kb = new Scanner(System.in);

        final int ROWS = 3;
        final int COLUMNS = 3;
        boolean finished = false;
        int rowpos, colpos;

        char[][] board = new char[ROWS][COLUMNS];

        //ASSIGN
        for (int row = 0; row < ROWS; row++) {
            for (int column = 0; column < COLUMNS; column++) {
                board[row][column] = '-';
            }//COLUMN
        }//ROW

        //PRINT
        for (int row = 0; row < ROWS; row++) {
            for (int column = 0; column < COLUMNS; column++) {
                System.out.print("(" + board[row][column] + ")\t");
            }//COLUMN
            System.out.println();
        }//ROW

        //GAME START
        int turns = 0;

        Gameloop:
        while (!finished) {


            //X-PLAYER TURN
            do {
                do {
                    System.out.print("X-PLAYER: Enter row you wish to place your 'X' in (0 - 2): ");
                    rowpos = kb.nextInt();
                    System.out.print("\nX-PLAYER: Enter column you wish to place your 'X' in (0 - 2): ");
                    colpos = kb.nextInt();
                    if (((rowpos < 0) || (rowpos > 2)) && ((colpos < 0) || (colpos > 2)))
                        System.out.println("Out of bounds, try again");
                } while (((rowpos < 0) || (rowpos > 2)) || ((colpos < 0) || (colpos > 2)));

                if (board[rowpos][colpos] != '-')
                    System.out.println("Tile occupied, try again");
            } while ((board[rowpos][colpos] != '-'));

            board[rowpos][colpos] = 'X';
            turns++;


            //PRINT
            for (int row = 0; row < ROWS; row++) {
                for (int column = 0; column < COLUMNS; column++) {
                    System.out.print("(" + board[row][column] + ")\t");
                }//COLUMN
                System.out.println();
            }//ROW


            //WIN TESTER
            if (turns >= 5) {
                for (int row = 0; row <= 2; row++) {
                    if ((board[row][0] == board[row][1]) && (board[row][0] == board[row][2]) && (board[row][0] != '-')) {
                        System.out.println(board[row][0] + "-Player wins!");
                        break Gameloop;
                    }
                }// ROW TESTER

                for (int column = 0; column <= 2; column++) {
                    if ((board[0][column] == board[1][column]) && (board[0][column] == board[2][column]) && (board[0][column] != '-')) {
                        System.out.println(board[0][column] + "-Player wins!");
                        break Gameloop;
                    }
                }// COLUMN TESTER

                //DIAGONAL TESTER
                if (((board[0][0] == board[1][1])) && (board[1][1] == board[2][2]) && (board[1][1] != '-')) {
                    System.out.println(board[1][1] + "-Player wins!");
                    break Gameloop;
                }
                if (((board[0][2] == board[1][1])) && (board[1][1] == board[2][0]) && (board[1][1] != '-')) {
                    System.out.println(board[1][1] + "-Player wins!");
                    break Gameloop;
                }
            }//WIN TESTER

            //FINAL WIN TESTER
            if (turns == 9) {
                for (int row = 0; row <= 2; row++) {
                    if ((board[row][0] == board[row][1]) && (board[row][0] == board[row][2])) {
                        System.out.println(board[row][0] + "-Player wins!");
                        break Gameloop;
                    }
                }// ROW TESTER

                for (int column = 0; column <= 2; column++) {
                    if ((board[0][column] == board[1][column]) && (board[0][column] == board[2][column])) {
                        System.out.println(board[0][column] + "-Player wins!");
                        break Gameloop;
                    }
                }// COLUMN TESTER

                //DIAGONAL TESTER
                if (((board[0][0] == board[1][1])) && (board[1][1] == board[2][2])) {
                    System.out.println(board[1][1] + "-Player wins!");
                    break Gameloop;
                }
                if (((board[0][2] == board[1][1])) && (board[1][1] == board[2][0])) {
                    System.out.println(board[1][1] + "-Player wins!");
                    break Gameloop;
                }
                else System.out.println("It's a draw!");
                break Gameloop;
            }//Final Tester




            //O-PLAYER TURN
            do {
                do {
                    System.out.print("O-PLAYER: Enter row you wish to place your 'O' in (0 - 2): ");
                    rowpos = kb.nextInt();
                    System.out.print("\nO-PLAYER: Enter column you wish to place your 'O' in (0 - 2): ");
                    colpos = kb.nextInt();
                    if (((rowpos < 0) || (rowpos > 2)) && ((colpos < 0) || (colpos > 2)))
                        System.out.println("Out of bounds, try again");
                } while (((rowpos < 0) || (rowpos > 2)) || ((colpos < 0) || (colpos > 2)));

                if (board[rowpos][colpos] != '-')
                    System.out.println("Tile occupied, try again");
            } while ((board[rowpos][colpos] != '-'));

            board[rowpos][colpos] = 'O';
            turns++;

            //PRINT
            for (int row = 0; row < ROWS; row++) {
                for (int column = 0; column < COLUMNS; column++) {
                    System.out.print("(" + board[row][column] + ")\t");
                }//COLUMN
                System.out.println();
            }//ROW

            //WIN TESTER
            if (turns >= 5) {
                for (int row = 0; row <= 2; row++) {
                    if ((board[row][0] == board[row][1]) && (board[row][0] == board[row][2]) && (board[row][0] != '-')) {
                        System.out.println(board[row][0] + "-Player wins!");
                        break Gameloop;
                    }
                }// ROW TESTER

                for (int column = 0; column <= 2; column++) {
                    if ((board[0][column] == board[1][column]) && (board[0][column] == board[2][column]) && (board[0][column] != '-')) {
                        System.out.println(board[0][column] + "-Player wins!");
                        break Gameloop;
                    }
                }// COLUMN TESTER

                //DIAGONAL TESTER
                if (((board[0][0] == board[1][1])) && (board[1][1] == board[2][2]) && (board[1][1] != '-')) {
                    System.out.println(board[1][1] + "-Player wins!");
                    break Gameloop;
                }
                if (((board[0][2] == board[1][1])) && (board[1][1] == board[2][0]) && (board[1][1] != '-')) {
                    System.out.println(board[1][1] + "-Player wins!");
                    break Gameloop;
                }
            }

        }//GAME WHILE LOOP



    }//main
}//class
